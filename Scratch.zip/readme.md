`Geometry Dash
-Minecraft Giấy (Paper Minecraft)
`Nhảy (Jump)
-Thung Lũng Huyền Bí (Mystic Valley)
-Appel
-Pokemon Clicker
~Bottle Flip
-Random Tycoon Thing
-Animate a Name Platformer
-Fortnite Z
`Ball Blast
-Old Western Way
-The Crusty Quest
-Trận Đấu Golf (Golf Battle)
`Tòa Nhà của Scratch
-Farming Interactive (Nông Trại Vui Vẻ)
`Slash Knight
~Hide and Seek (Trốn Tìm)
`Sinh Vật (Creature)
Spacevale
`City Simulator
Máy Bay (Airplane)
-Quyết Đấu! (Duel)
`Trò Chơi Thủ Thành (Tower Defense Game)
-Fortnite Online

